@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === SEMO Oracle ERP - Windows build ===
where node >nul 2>nul || (echo Node.js is not installed. Install Node.js LTS first.& pause & exit /b 1)
call npm install
if errorlevel 1 (echo npm install failed.& pause & exit /b 1)
call npm run dist:win
if errorlevel 1 (echo Windows installer build failed.& pause & exit /b 1)
echo Build completed. Check the release folder.
pause
